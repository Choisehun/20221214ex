package com.data;

import java.time.LocalDate;


import Util.Pr;


public class Post {
	public String title;
	public String name;
	public String coment;
	public int Numb;
	static int no;
	public int hit;
	public int pw = 1234;
	



	public Post(String title, String name, String coment) {
		no = no+1;
		this.title = title;
		this.coment = coment;
		this.name = name;	
		this.Numb = no;
		this.hit = hit;
		
		
	}
	
	public void ProMenuList() {
		Pr.pn("글번호: " + Numb +"번 " +" 글 제목 : " + title + " 작성자: " + name);
	}

	public void ProMenuRead() {
		Pr.pn("글번호: " + Numb);
		Pr.pn("글 제목: " + title);
		Pr.pn("글 내용: " + coment + " 조회수: " +hit);
	}




	





	





	















	
}
