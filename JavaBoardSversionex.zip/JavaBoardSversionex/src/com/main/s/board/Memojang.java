package com.main.s.board;

import com.data.Data;

public class Memojang {
	/*
	 Main 에서는 출력만함.
	 Dis에서 고양이카페와 글리스트 등 표현후 Board 에서 출력함.
	 Data Post 만들어서 입력받은 내용 저장 및 출력
	 Data.loadData(); Board에 추가함.
	
	 
	 int searchnum =0;
	 
	 for(int i=0; i<Data.posts.size(); i++){
	 	if(cmd.equals(Data.posts.get(i).instanceNo+"")){
	 		searchnum = i;
	 	}
	 	}
	 	Data.posts.remove(searchnum);
	  */
	
	
}
