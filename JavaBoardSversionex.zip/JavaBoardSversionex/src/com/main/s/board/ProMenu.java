package com.main.s.board;

import java.util.Scanner;

import Display.Dis;
import Util.Pr;
import Util.Psc;

public class ProMenu {
		
	static void run() {
			
			
		
			loop:
			while(true) {
				String cmd = Psc.r("메인 번호 선택 ");
				System.out.println();
				switch(cmd) {
				case "1":
					ProMenuWrite.run();
					break;
					
				case "2":
					ProMenuList.run();
					break;
					
				case "3":
					ProMenuRead.run();
					break;
					
				case "4":
					ProMenuDel.run();
					break;
					
				case "5":
					ProMod.run();
					break;
					
				case "x":
					System.out.println("종료했습니다.");
					break loop;
				}
				
			}
				
				
			
		}

}
