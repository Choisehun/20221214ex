package com.main.s.board;

import com.data.Data;
import com.data.Post;

import Util.Pr;
import Util.Psc;

public class ProMenuDel {
	
	public static void run() {
		
		int SearchNumb = 0;
		
		
		
		
		String cmd = Psc.r("1.번호삭제 2.전체삭제 3.취소");
		
			loof:switch(cmd) {
			
			case "1":
				
				Psc.r("몇번 게시물을 삭제");
				for(int i=0; i<Data.posts.size(); i++) {
					if(cmd.equals(Data.posts.get(i).Numb+"")) {
						SearchNumb = i;
					}
				}//for
				
				cmd = Psc.r("비밀번호 입력");
				if(cmd.equals("1234")) {
					Data.posts.remove(SearchNumb);
				}else {
					System.out.println("다시입력하세요");
				}

				
				break;
				
			case "2":
				int count = Data.posts.size();
				for(int i=0; i<count; i++) {
					Data.posts.remove(0);
					
				}
				System.out.println("전체삭제완료");

				break;
				
			case "3":
				System.out.println("뒤로가기");
				break loof;
			}
						
				
		
		
	}

		

}
