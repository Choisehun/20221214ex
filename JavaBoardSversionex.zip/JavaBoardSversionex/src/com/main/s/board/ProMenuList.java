package com.main.s.board;

import com.data.Data;
import com.data.Post;

import Util.Pr;

public class ProMenuList {
public static void run() {

		int count = Data.posts.size();
	for(Post p:Data.posts) {
		p.ProMenuList();
			
	}
	if(count ==0) {
		System.out.println("저장된 글이없습니다.");
		System.out.println();
	}else {
		System.out.println("글 갯수:" + count);
	}
	
}

}
