package com.main.s.board;

import com.data.Data;
import com.data.Post;

import Util.Pr;
import Util.Psc;

public class ProMenuRead  {

	
	public static void run() {
		
	
		int hit=0;
		String cmd = Psc.r("몇번글 선택");
		for(Post d: Data.posts) {
			if(cmd.equals(d.Numb+"")) {
				d.ProMenuRead();
				d.hit = hit+1;	
				
			}
		}
		
	
	}
	
}

