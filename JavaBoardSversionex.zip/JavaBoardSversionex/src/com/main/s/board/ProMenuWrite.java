package com.main.s.board;


import com.data.Data;
import com.data.Post;


import Util.Pr;
import Util.Psc;

public class ProMenuWrite {
	
	static void run() {
		
		System.out.println("게시판 글 작성");
		
		
		String title;
		while(true) {
			title =Psc.r1("제목");
			if(title.length()>0) {
				break;
			}else {
				System.out.println("다시입력하세요");
			}
		}//while
		
		String coment;
		while(true) {
			coment = Psc.r1("내용 입력");
			if(coment.length()>0) {
				break;
			}else {
				System.out.println("다시입력해주세요");
			}
		}
		
		String name;
		while(true) {
			name = Psc.r("작성자");
			if(name.length()>0) {
				break;
			}else {
				System.out.println("다시입력하세요");
			}
		}//while
		
		
		Post p = new Post(title,coment,name);
		Data.posts.add(p);
		
		
		
			
	}
		
}
