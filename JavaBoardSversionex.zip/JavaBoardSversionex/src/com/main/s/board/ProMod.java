package com.main.s.board;

import com.data.Data;
import com.data.Post;

import Util.Pr;
import Util.Psc;

public class ProMod {


	public static void run() {
		for(Post d:Data.posts) {
			String cmd = Psc.r("1.제목 수정 2.내용 수정 3. 작성자 수정 4.뒤로 가기");
			
			switch(cmd) {
			case "1":
				String title=Psc.r1("제목 수정");
				d.title = title;
				System.out.println("완료");
				break ;
			case "2":
				String coment=Psc.r1("내용 수정");
				d.coment = coment;
				System.out.println("완료");
				break;
			case"3":
				String name=Psc.r("작성자 수정");
				d.name=name;
				System.out.println("완료");
				break;
			case"4":
				System.out.println("뒤로가기");
				break;
			}
			
			
		}
	}
	
}
